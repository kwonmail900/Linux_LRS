#include <stdio.h>
#include "common.h"

void print(char* str)
{
    printf("%s", str);
}
