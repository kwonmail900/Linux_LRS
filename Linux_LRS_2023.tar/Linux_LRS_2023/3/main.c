#include "common.h"

int main( )
{
    char* str = input( );
    print(str);
    print("\n");

    return 0;
}
