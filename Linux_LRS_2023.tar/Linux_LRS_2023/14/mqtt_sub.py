import paho.mqtt.client as mqtt

# MQTT Broker configuration
broker_address = '127.0.0.1'
broker_port = 1883
topic = 'my/topic'

# Callback function when connected to MQTT broker
def on_connect(client, userdata, flags, rc):
    print("Connected to MQTT broker")

    # Subscribe to the topic
    client.subscribe(topic)

# Callback function when a message is received
def on_message(client, userdata, msg):
    print(f"Received: {msg.payload.decode()}")

# Create an MQTT client instance
client = mqtt.Client()

# Set callback functions
client.on_connect = on_connect
client.on_message = on_message

# Connect to the MQTT broker
client.connect(broker_address, broker_port)

# Start the MQTT network loop
client.loop_forever()

