from flask import Flask, render_template
import eventlet
from eventlet import wsgi
from eventlet.websocket import WebSocket

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index_wsgi_eventlet.html')

@WebSocket('/')
def ws_handler(ws):
    while True:
        message = ws.wait()
        if message is None:
            break
        print('Received message:', message)
        ws.send('Server received: ' + message)

if __name__ == '__main__':
    listener = eventlet.listen(('0.0.0.0', 5000))
    wsgi.server(listener, app)

