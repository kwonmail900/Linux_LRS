#!/usr/bin/python 
import pymysql 

conn = pymysql.connect(
    user="scott",
    password="tiger",
    host="localhost",
    db="mydb")
cur = conn.cursor() 

#retrieving information 
some_name = "Sensor2" 
cur.execute("select b.id, a.name, b.sensor_id, b.reading, b.timestamp, c.status from Sensors a, SensorData b, SensorStatus c WHERE a.id=b.sensor_id and a.id=c.sensor_id and a.name=?", (some_name,)) 

for b.id, a.name, b.sensor_id, b.reading, b.timestamp, c.status in cur: 
    print(f"ID: {b.id}, Name: {a.name}, Sensor_id: {b.sensor_id}, Reading: {b.reading}, Timestamp: {b.timestamp}, Status: {c.status}")
    
#insert information 
try: 
    cur.execute("INSERT INTO SensorData (sensor_id, reading, timestamp) VALUES (?, ?, CURRENT_TIMESTAMP)", (2, 30.5)) 
except mariadb.Error as e: 
    print(f"Error: {e}")

conn.commit() 
print(f"Last Inserted ID: {cur.lastrowid}")
    
conn.close()
