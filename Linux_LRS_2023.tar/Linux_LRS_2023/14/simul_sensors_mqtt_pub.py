import datetime
import random
import time
import paho.mqtt.client as mqtt

# MQTT Broker configuration
broker_address = 'broker.hivemq.com'
broker_port = 1883
topic = 'sensors'

# Function to simulate and send values in real-time
def simulate_and_send(client):
    while True:
        current_time = datetime.datetime.now()
        temperature = random.uniform(20, 30)
        humidity = random.uniform(40, 60)
        illuminance = random.uniform(500, 1000)
        
        data = {
            'time': current_time.strftime('%Y-%m-%d %H:%M:%S'),
            'temperature': temperature,
            'humidity': humidity,
            'illuminance': illuminance
        }
        client.publish(topic, str(data))  # Publish data to MQTT broker
        
        print(f"Time: {current_time} - Temperature: {temperature:.2f}°C, Humidity: {humidity:.2f}%, Illuminance: {illuminance:.2f} lux")
        
        time.sleep(1)  # Delay for real-time effect

# MQTT client setup and connection
client = mqtt.Client()
client.connect(broker_address, broker_port)

# Start the simulation and publishing process
simulate_and_send(client)

