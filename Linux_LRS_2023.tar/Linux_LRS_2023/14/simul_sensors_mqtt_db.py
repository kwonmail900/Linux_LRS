import datetime
import random
import time
import paho.mqtt.client as mqtt
import pymysql

# MQTT Broker configuration
#broker_address = 'broker.hivemq.com'
broker_address = '127.0.0.1'
broker_port = 1883
publish_topic = 'sensors'
subscribe_topic = 'sensors'

# MariaDB database configuration
db_host = 'localhost'
db_user = 'scott'
db_password = 'tiger'
db_name = 'mydb'
table_name = 'SensorData'

# MQTT client setup and connection
mqtt_client = mqtt.Client()
mqtt_client.connect(broker_address, broker_port)

# MQTT message callback
def on_message(client, userdata, message):
    try:
        payload = message.payload.decode()
        data = eval(payload)  # Safely convert the string payload to a dictionary
        
        # Connect to the MariaDB database
        db_connection = pymysql.connect(host=db_host, user=db_user, password=db_password, database=db_name)
        cursor = db_connection.cursor()

        # Extract values from the received data
        timestamp = datetime.datetime.strptime(data['time'], '%Y-%m-%d %H:%M:%S')
        sensor_id = data['sensor_id']
        reading = data['reading']
        temperature = data['temperature']
        humidity = data['humidity']
        illuminance = data['illuminance']

        # Insert the values into the database
        query = f"INSERT INTO {table_name} (sensor_id, reading, timestamp, temperature, humidity, illuminance) VALUES (%s, %s, %s, %s, %s, %s)"
        cursor.execute(query, (sensor_id, reading, timestamp, temperature, humidity, illuminance))
        db_connection.commit()

        # Close the database connection
        db_connection.close()

        print(f"Received and stored: Time: {timestamp},  SID: {sensor_id},  Rd: {reading}, Temp: {temperature}°C, Humi: {humidity}%, Illu: {illuminance} lux")

    except Exception as e:
        print(f"Error: {e}")

# MQTT client subscription and loop
mqtt_client.subscribe(subscribe_topic)
mqtt_client.on_message = on_message
mqtt_client.loop_start()

# Function to simulate and send values in real-time
def simulate_and_send(client):
    while True:
        current_time = datetime.datetime.now()
        sensor_id = random.uniform(1,4)
        reading = random.uniform(20, 30)
        temperature = random.uniform(20, 30)
        humidity = random.uniform(40, 60)
        illuminance = random.uniform(500, 1000)

        data = {
            'time': current_time.strftime('%Y-%m-%d %H:%M:%S'),
            'sensor_id': sensor_id,
            'reading': reading,
            'temperature': temperature,
            'humidity': humidity,
            'illuminance': illuminance
        }
        client.publish(publish_topic, str(data))  # Publish data to MQTT broker

        print(f"Time: {current_time} - SID: {sensor_id:.2f}°C, Rd: {reading:.2f}°C, Temp: {temperature:.2f}°C, Humi: {humidity:.2f}%, Illu: {illuminance:.2f} lux")

        time.sleep(1)  # Delay for real-time effect

# Start the simulation and publishing process
simulate_and_send(mqtt_client)

