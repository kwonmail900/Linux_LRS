import paho.mqtt.client as mqtt

# MQTT Broker configuration
broker_address = '127.0.0.1'
broker_port = 1883
topic = 'mytopic'

# Callback function when connected to MQTT broker
def on_connect(client, userdata, flags, rc):
    print("Connected to MQTT broker")

    # Subscribe to a topic
    client.subscribe(topic)

# Callback function when a message is received
def on_message(client, userdata, msg):
    print(f"Received message: {msg.payload.decode()}")

# Create an MQTT client instance
client = mqtt.Client()

# Set callback functions
client.on_connect = on_connect
client.on_message = on_message

# Connect to the MQTT broker
client.connect(broker_address, broker_port)

# Start the MQTT network loop
client.loop_start()

# Publish a message to a topic
client.publish(topic, "Hello, MQTT!")

# Keep the script running
while True:
    pass

