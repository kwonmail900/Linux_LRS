import datetime
import random
import time
from multiprocessing import Process, Queue

# Function to simulate and send values in real-time
def simulate_and_send(queue):
    while True:
        current_time = datetime.datetime.now()
        temperature = random.uniform(20, 30)
        humidity = random.uniform(40, 60)
        illuminance = random.uniform(500, 1000)
        
        data = {
            'time': current_time,
            'temperature': temperature,
            'humidity': humidity,
            'illuminance': illuminance
        }
        queue.put(data)  # Send data via the queue
        
        print(f"Time: {current_time} - Temperature: {temperature:.2f}°C, Humidity: {humidity:.2f}%, Illuminance: {illuminance:.2f} lux")
        
        time.sleep(1)  # Delay for real-time effect

# Main process
if __name__ == '__main__':
    queue = Queue()  # Message queue for interprocess communication
    
    # Start the process for simulating and sending values
    simulation_process = Process(target=simulate_and_send, args=(queue,))
    simulation_process.start()
    
    # Main loop to receive and process the values
    while True:
        if not queue.empty():
            data = queue.get()  # Receive data from the queue
            
            # Process the received values as needed
            # Example: Print the received values
            print(f"Received: Time: {data['time']} - Temperature: {data['temperature']:.2f}°C, Humidity: {data['humidity']:.2f}%, Illuminance: {data['illuminance']:.2f} lux")

