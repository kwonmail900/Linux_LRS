import paho.mqtt.client as mqtt
import time

# MQTT Broker configuration
broker_address = '127.0.0.1'
broker_port = 1883
topic = 'my/topic'

# Create an MQTT client instance
client = mqtt.Client()

# Connect to the MQTT broker
client.connect(broker_address, broker_port)

# Publish a message to the topic every 1 second
while True:
    message = f"Hello, MQTT! Time: {time.strftime('%H:%M:%S')}"
    client.publish(topic, message)
    print(f"Published: {message}")
    time.sleep(1)

