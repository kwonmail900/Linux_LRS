import datetime
import random
import time
import paho.mqtt.client as mqtt

# MQTT Broker configuration
broker_address = 'broker.hivemq.com'
broker_port = 1883
publish_topic = 'sensors2023'
subscribe_topic = 'sensors2023'

# MQTT client setup and connection
client = mqtt.Client()
client.connect(broker_address, broker_port)

# Callback function when a message is received
def on_message(client, userdata, message):
    payload = message.payload.decode()
    print(f"Received: {payload}")

# Setup MQTT client subscription and message callback
client.subscribe(subscribe_topic)
client.on_message = on_message

# Function to simulate and send values in real-time
def simulate_and_send(client):
    while True:
        current_time = datetime.datetime.now()
        temperature = random.uniform(20, 30)
        humidity = random.uniform(40, 60)
        illuminance = random.uniform(500, 1000)
        
        data = {
            'time': current_time.strftime('%Y-%m-%d %H:%M:%S'),
            'temperature': temperature,
            'humidity': humidity,
            'illuminance': illuminance
        }
        
        payload = str(data)
        client.publish(publish_topic, payload)
        
        print(f"Time: {current_time} - Temperature: {temperature:.2f}°C, Humidity: {humidity:.2f}%, Illuminance: {illuminance:.2f} lux")
        
        time.sleep(1)  # Delay for real-time effect

# Start the simulation and publishing process
simulate_and_send(client)

# Start the MQTT client loop to receive messages (runs in parallel)
client.loop_start()

