#!/bin/bash

SET=$(seq 1 14)
for i in $SET
do
	echo "Running loop seq "$i
	mkdir $i
	# some instructions
done
